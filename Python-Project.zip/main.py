#Game Idea: A game where the user will have to face multiple battles against CPUs. After each CPU, the player will have a choice to either increase their health, or their attack damage for future battles. The bosses will get harder over time and finally once the last boss is killed, the game will end. (Maybe the thank you title screen?). ---- 
#Game Format: Beginning with a character selection type choice. Each character will have differences in health or damage but each one may be stronger than the other or more health than another. Once it is picked, A scenario will given (kinda like the orgeon trail game where you can look around, and overall just describing the setting through narratives and exploration options). After, the user will be prompted to go and travel and reaching each "focal point", there will be something. Maybe a health booster, enemy, or even just a place that explains more of the narrative just like the spawn. There will 3 Focal Points before eaching the main kingdom. There will also be mini-games along the way that will fit into the storyline such as number guess, trivia, etc. that will be helpful to health.
#Game Narrative: Setting the scene, a friend has been captured by a rivalrous king and the user has been dropped in the woods. With only a map and a couple supplies for battle, the user has to make their way to save their friend going through battles between enemies and saving their friend frpm the tyrannical king. 
import random
print("Dropped in the woods, you see a knight on a horse along with your friend saying 'just following king's orders.' The last thing you remember is having a drink at the Tavern along with a your best buddy when a Tyrant king was calling your name and stole you and your friend. Keeping your friend, you notice he headed towards his castle.")
print()

print("However, the only path that is given is the path shown to you. You notice a sign guiding the path. The wooden sign shows three landmarks and then the kingdom. Each landmark has a symbol. The first being a skull, second being a tiger, and third being a man that has wisdom written next to him. On the top of the sign states, 'Your goal is to save your friend by going down the path. Each landmark may have an obstacle where you will be able to play a mini-game to pass through. The only thing you will recieve is a pair of magic dice that will make certain executive decisions. Good luck solider.' Let the journey begin!")
print()

#beginning the game
def begin():
  uChoiceBegin = input(" Enter 'search' to look around and 'follow' to go on the path. ")
  if uChoiceBegin == "search":
    print()
    print("Surrounding you is a forest full of trees, rocks and other debris. You look around and see you have nothing in hand. You decide to pick up a small used to be sign stating 'Welcome to the forest.' You begin your journey!")
  else:
    print()
    print("You begin your journey!")
begin()

#First Level - Graveyard
def graveyard():
  print("You walk along the path and notice a gravesite coming up. A path leads straight to the other side. 'Beware of ghosts. Lost bodies found.' a sign reads. You walk across and suddenly you see a ghost in your path, do you go up to the ghost and befriend it, or do you plan to battle it in a duel? - beware! you could lose your progress.")

  print()
  uChoiceGraveYrd = input("say 'befriend' to attempt befriend and 'battle' to fight. ")
  if uChoiceGraveYrd == "befriend":
    print()
    print("The ghost was not friendly and decided to sabotage you. He takes over your body and brings you back to the grave. You lose. Good game.")
    exit()
  else:
    print("The ghost says a riddle. 'My favorite flavor of icecream is 'BOO'-berry. To move on, you must complete a task in three turns. Please enter one at a time. No Captialization please.")
    print()
    #Game begins:
    wrong = 0 
    right = 0
    repeat = []
    icFlavors = ["chocolate","vanilla","strawberry"]
    while right<3 and wrong<3:
      Uinpt = input("Guess the ghost's favorite icecream flavors (Hint: 3 common flavors) ")
      if Uinpt in repeat:
        print("You have already guessed this flavor. Please list a different flavor")
      else: 
        if Uinpt in icFlavors:
          repeat.append(Uinpt)
          right +=1
          print(Uinpt, "is one of my favorite icecream flavors.")
        else:
          print("Nope! That is not one of my favorite icecream flavors!")
          repeat.append(Uinpt)
          wrong +=1
      print("You have", right, "right guesses and", wrong, "wrong guesses.")

  #Win Condition
  global cont
  if right == 3:
    print()
    print("Congrats! You guessed three of the ghost's favorite icecream flavors and you manage to escape the graveyard.")
    print()
    cont = True
  else:
    print("You didn't guess it. Good game! ")
    exit()
    cont = False
graveyard()

#Level 2 - Tiger's Den.
def tiger():
  #Cut Scene - Tigers Den
  if cont == True:
    print("After persuing the journey through the graveyard, you notice that you see a jungle ahead. As the path slowly diverges from a forest to a jungle, you see an open area with a 5 foot long tiger napping in the middle, you see that you need to get around it to get to the next area. You attempt to walk around it, each step with caution, however, you end up making noise and the tiger awakes.")
    print()
    print("You panic and decide to pull out the magical dice you were given. A note was attached saying 'rolling a high number will help you. But rolling too high will hurt you.' The special idea you notice about the two dice is that the amount of sides that the dice has however many sides the user wants to put. With the dice, you are given a range that you will need to be in to survive. Your dice will be twice and if you are not in the range, bad things will happen. (Has to be positive number higher than one).")
    print()
    #Sets up for the dice game. 
    print()
    Ud1 = int(input("Please put the integer that decides the amount of sides of the first dice "))
    print()
    print()
    Ud2 = int(input("Please input the # of the sides that you would like for the second dice to have."))
    #Chooses a random integer you choose whether or not is in range
    randNum1 = random.randint(1, Ud1)
    print("Dice 1:", randNum1)
    randNum2 = random.randint(1, Ud2)
    print("Dice 2:", randNum2)
    ttlDice = randNum1 + randNum2 
    print("Your total was, ", ttlDice)
    if ttlDice > 9 < 40:
      print("Congrats! You win! You managed to survive and the tiger is put to a drowsy sleep that will last for a couple minutes. You run out and leave the jungle area. Hurrying over to the next landmark...")
      global cont1
      cont1 = True
    else:
      print("You were not in the range and you lost. Good Game!")
      cont1 = False
      exit()
tiger()

#Level 3 - City of Wisdom
def wisdomT():
  if cont1 == True:
    print()
    #Cut scene
    print("Congrats for making it out of the jungle! With the knowledge of having two stages complete, you feel very confident with yourself. You find youself at the foot of what looks to be a Zen Garden. A Man is meditiating and you plan to walk past him. You take a couple steps and suddenly, the man halts you. You decide to run but then the path suddenly disappears with the snap of his finger. 'You dare leave me?' Without hesitation, you pause and stop in your tracks.")
    print()
    #Bank of Questions and Answers
    TQb = ["What is a group of lions called?", "How many arms does an Octopus have?", "Which bird can mimic human speech?"]
    tAb = ["pride", "a pride", "Pride", "A pride", "8", "eight", "parrot", "A parrot", "A Parrot", "Parrot"]
    print("He asks...", random.choice(TQb))
    DecisionW = input("Please input your answer:")
    if DecisionW in tAb: 
      print("That is correct! The path reappears and you are left free to go. You quickly scurry out. Leading to the last POI.")
    else:
      print("Wrong choice. You are left in the garden with no exit and you are stuck forever. Good game.")
      exit()
wisdomT()

#Final Cutscene
def final():
    print("You walk up to the doors of the castle that your friend has been stuck in. Finally, peace at last. You enter the doors and right as you walk in your see your friend stuck in a cage. The king states: are you worthy?")
    print()
    print("*he notices your used dice.*")
    print()
    print("You truly are worthy. If you've made it on this path, then I must leave you with kingsmenship. You are left to serve the community with an honor. He leaves the castle with shackles around his arms and leaves the kingsmenship towards you. Thank you for playing.")
final()